ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter)

Attachments:
1. attachment_1_https___bidenwhitehouse_archiv.pdf (original URL: https://bidenwhitehouse.archives.gov/briefing-room/presidential-actions/2021/02/24/notice-on-the-continuation-of-the-national-emergency-concerning-the-coronavirus-disease-2019-covid-19-pandemic/)
2. attachment_2_https___www_gov_ca_gov_2020_03.pdf (original URL: https://www.gov.ca.gov/2020/03/04/governor-newsom-declares-state-of-emergency-to-help-state-prepare-for-broader-spread-of-covid-19/)
3. attachment_3_https___www_gov_ca_gov_wp_cont.pdf (original URL: https://www.gov.ca.gov/wp-content/uploads/2020/03/3.19.20-attested-EO-N-33-20-COVID-19-HEALTH-ORDER.pdf)

Generated on: 2025-03-03T14:46:33.625Z
