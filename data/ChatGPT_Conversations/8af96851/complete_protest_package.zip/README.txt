ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter)

Attachments:
1. attachment_1_https___bidenwhitehouse_archiv.pdf (original URL: https://bidenwhitehouse.archives.gov/briefing-room/presidential-actions/2021/02/24/notice-on-the-continuation-of-the-national-emergency-concerning-the-coronavirus-disease-2019-covid-19-pandemic/)
2. attachment_2_https___www_gov_ca_gov_2020_03.pdf (original URL: https://www.gov.ca.gov/2020/03/19/3-19-20-attested-eo-n-33-20-covid-19-health-order/)
3. attachment_3_https___www_gov_ca_gov_2020_08.pdf (original URL: https://www.gov.ca.gov/2020/08/28/governor-newsom-unveils-blueprint-for-a-safer-economy-a-statewide-stringent-and-slow-plan-for-living-with-covid-19/)
4. attachment_4_https___cms7files_revize_com_c.pdf (original URL: https://cms7files.revize.com/camarilloca/Departments/Community%20Development/Applications/Reso%202020-63.pdf)

Generated on: 2025-03-03T21:58:36.384Z
