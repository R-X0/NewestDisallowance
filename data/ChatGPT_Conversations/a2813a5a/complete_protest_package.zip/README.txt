ERC PROTEST PACKAGE

Main Document:
- protest_letter.pdf (The main protest letter)

Attachments:
1. attachment_1_https___bidenwhitehouse_archiv.pdf (original URL: https://bidenwhitehouse.archives.gov/briefing-room/presidential-actions/2021/02/24/notice-on-the-continuation-of-the-national-emergency-concerning-the-coronavirus-disease-2019-covid-19-pandemic/#:~:text=On%20March%2013,%202020,...)
2. attachment_2_https___www_cdph_ca_gov_Progra.pdf (original URL: https://www.cdph.ca.gov/Programs/CID/DCDC/CDPH%20Document%20Library/COVID-19/8-28-20_Order-Plan-Reducing-COVID19-Adjusting-Permitted-Sectors-Signed.pdf#:~:text=to%20the%20end%20of%20the,...)

Generated on: 2025-03-03T15:12:29.744Z
